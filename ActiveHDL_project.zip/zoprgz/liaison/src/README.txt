
This folder contains a ActiveHDL project representing the work of Group 3 in TFE4140

The project was working on our computer, but since we have had trouble with opening old ActiveHDL projects,
this file explains how the project is set up.

It is pretty simple, all .hdl files at root are source files, where liaison.hdl is the top-level. The two TB-files
are not in use for ActiveHDL, but was used during development with Xilinx ISE. The TestBench file for ActiveHDL is
found under the TestBench folder.

BR.
Benjamin Bjørnseth and Stian Hvatum
